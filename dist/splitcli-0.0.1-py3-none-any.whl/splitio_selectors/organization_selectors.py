def manage_organization():
    return