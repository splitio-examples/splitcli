
def manage_metrics():
    return